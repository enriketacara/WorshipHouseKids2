document.addEventListener("DOMContentLoaded", function() {
    const featuredGlide = new Glide('.featured_games_glide', {
      type: 'carousel',
      perView: 5,
      focusAt: 'center',
      gap: 10,
      breakpoints: {
        1024: { perView: 5 },
        768: { perView: 3 },
        480: { perView: 3 }
      }
    });

    featuredGlide.on(['run.after'], () => {
      document.querySelectorAll('.featured_games_glide__slide img').forEach(img => {
        img.style.transform = 'scale(1)';
      });
      
      const activeSlide = document.querySelector('.featured_games_glide .glide__slide--active img');
      if (activeSlide) {
        activeSlide.style.transform = 'scale(1.2)';
      }
    });

    featuredGlide.mount();

    const newArrivalsGlide = new Glide('.myGlideContainer', {
		type: 'carousel', 
      startAt: 0,
      perView: 1,
      autoplay: false, 
      hoverpause: true, 
      breakpoints: {
        1024: { perView: 1 },
        768: { perView: 1 },
        480: { perView: 1 }
      }
    });

    newArrivalsGlide.mount();
  });

  const cardGlide = new Glide('.card_carousel_glide', {
      type: 'carousel',
      perView: 4,
      focusAt: 'center',
      gap: 35,
      autoplay: 5000,
      hoverpause: false,
      animationDuration: 15000,
      breakpoints: {
        1024: { perView: 4 },
        768: { perView: 2 },
        480: { perView: 2 }
      }
    });

    cardGlide.mount();


	const newProductsGlide = new Glide('.new_products_glide', {
      type: 'carousel',
      perView: 4,
      gap: 20,
      autoplay: 5000,
      hoverpause: false,
      breakpoints: {
        1024: { perView: 4 },
        768: { perView: 2 },
        480: { perView: 2 }
      }
    });

    newProductsGlide.mount();

// Js code for the active tabs ,best seller
	document.addEventListener("DOMContentLoaded", function () {
    const tabs = document.querySelectorAll(".tab-link");

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active"); 
        });
    });
});


// Js code for the active tabs ,the latest
document.addEventListener("DOMContentLoaded", function () {
    const tabs = document.querySelectorAll(".latest-tab");

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active"); 
        });
    });
});

  document.addEventListener("DOMContentLoaded", function() {
      const menuToggle = document.querySelector(".menu-toggle");
      const menu = document.querySelector(".menu");

      menuToggle.addEventListener("click", function() {
          menu.classList.toggle("active");
      });
  });

  





